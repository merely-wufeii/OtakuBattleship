The bgm audio autoplays on safari but not on chrome, so I changed it to both playing when game clicked.
Also Safari doesn't play multiple files at the same time for me.

The background room art is found online, otherwise all other ones are created by me with reference to popular works such as Genshin Impact, hunter x hunter etc. I also took the opera audio and bgm online.

I don't have enough energy and time to do draggable ships and positioning them so I just did randomize :(

My code has some weird bugs that I couldn't figure out how to do:
1. It sometimes prevents me from scrolling down lower than my switch button and I have to refresh it.

2. If I run the smart computer will sometimes give an error of undefined while I check for undefine? And will freeze. This happens with ships on the boarders. My smart computer would also run into infinite loops if, for example, it goes through 2 vertical ships placed together but sees it as a horizontal one. 

I also have a lot of commented out codes which were my previous tries for doing things and I kept it just in case and also to show my journey of trial and error and hardship.


